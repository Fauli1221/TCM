mainMenu {
    enabled = true
    label {
        position {
            x { it - 2 }
            y { it - 20 }
        }
        text = literal("Fauli's Techtastisch Community Modpack Back to Normal Upgrade V1.6-1.17.1")
        align = "right"
        color = 0xFFFFFF
        hoveredColor = 0x55FFFF
        shadow = true
        onClicked = url("https://github.com/Fauli1221/TCM")
    }
}
